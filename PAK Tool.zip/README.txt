Now, what does lock-on serve here? It allows you to add custom levels to the game!
This is a simple package that allows you to create your own add-on file, which is a single level editable by SonLVL. 
Please note, you're expected to use Windows or some sort of way to run Windows applications (like Wine) for this to work.
Limitations of these custom levels is that you can't have any objects or backgrounds in the stage, you can't change the spawn location, and levels are always limited to the same size.

When you're satisfied with your level, run "build.bat" and it'll create your .PAK file.
You can share around these .PAK files you created with other people or communities to play your level! 
To add them to the game, put the MD-SONIC ROM in the folder, and run "lockon.bat". 
A new ROM will be generated, and you can play your level through a new selection in the level select simply identified with ".PAK".
Have fun creating! - MDTravis